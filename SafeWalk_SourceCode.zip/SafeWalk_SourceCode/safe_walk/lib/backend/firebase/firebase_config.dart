import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/foundation.dart';

Future initFirebase() async {
  if (kIsWeb) {
    await Firebase.initializeApp(
        options: FirebaseOptions(
            apiKey: "AIzaSyDFk3ilAvUPfY_iAiRtXnrj8pfSu918cM8",
            authDomain: "safewalk-7e852.firebaseapp.com",
            projectId: "safewalk-7e852",
            storageBucket: "safewalk-7e852.firebasestorage.app",
            messagingSenderId: "503072319192",
            appId: "1:503072319192:web:320edeb9474ca9be6b19ad"));
  } else {
    await Firebase.initializeApp();
  }
}
