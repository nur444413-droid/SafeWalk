import '/auth/firebase_auth/auth_util.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_icon_button.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/upload_data.dart';
import 'dart:ui';
import '/flutter_flow/custom_functions.dart' as functions;
import '/index.dart';
import 's_o_s_page_widget.dart' show SOSPageWidget;
import 'package:flutter/material.dart';
import 'package:flutter/scheduler.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';

class SOSPageModel extends FlutterFlowModel<SOSPageWidget> {
  ///  State fields for stateful widgets in this page.

  bool isDataUploading_uploadedPhotoUrl = false;
  FFUploadedFile uploadedLocalFile_uploadedPhotoUrl =
      FFUploadedFile(bytes: Uint8List.fromList([]), originalFilename: '');
  String uploadedFileUrl_uploadedPhotoUrl = '';

  @override
  void initState(BuildContext context) {}

  @override
  void dispose() {}
}
