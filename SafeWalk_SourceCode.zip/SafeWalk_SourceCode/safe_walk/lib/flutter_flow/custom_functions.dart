import 'dart:convert';
import 'dart:math' as math;

import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:intl/intl.dart';
import 'package:timeago/timeago.dart' as timeago;
import 'lat_lng.dart';
import 'place.dart';
import 'uploaded_file.dart';
import '/backend/backend.dart';
import 'package:cloud_firestore/cloud_firestore.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/auth/firebase_auth/auth_util.dart';

String? getLiveMapLink(LatLng? loc) {
  if (loc == null) return "Location not found";
  final lat = loc.latitude;
  final lon = loc.longitude;
  return "https://www.openstreetmap.org/?mlat=$lat&mlon=$lon#map=17/$lat/$lon";
}
