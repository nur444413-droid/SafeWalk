// Automatic FlutterFlow imports
import '/backend/backend.dart';
import '/backend/schema/structs/index.dart';
import '/backend/supabase/supabase.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import 'index.dart'; // Imports other custom widgets
import '/flutter_flow/custom_functions.dart'; // Imports custom functions
import 'package:flutter/material.dart';
// Begin custom widget code
// DO NOT REMOVE OR MODIFY THE CODE ABOVE!

import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart' as ll; // Added 'as ll' alias here

class FreeOSM extends StatefulWidget {
  const FreeOSM({
    Key? key,
    this.width,
    this.height,
    this.startLocation,
  }) : super(key: key);

  final double? width;
  final double? height;
  final LatLng? startLocation; // This uses FlutterFlow's LatLng

  @override
  _FreeOSMState createState() => _FreeOSMState();
}

class _FreeOSMState extends State<FreeOSM> {
  @override
  Widget build(BuildContext context) {
    // Convert FlutterFlow LatLng to latlong2 format using the 'll' prefix
    final ll.LatLng mapCenter = ll.LatLng(
      widget.startLocation?.latitude ?? 0.0,
      widget.startLocation?.longitude ?? 0.0,
    );

    return Container(
      width: widget.width,
      height: widget.height,
      child: FlutterMap(
        options: MapOptions(
          initialCenter: mapCenter,
          initialZoom: 15.0,
        ),
        children: [
          TileLayer(
            urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          ),
          MarkerLayer(
            markers: [
              Marker(
                point: mapCenter,
                width: 40,
                height: 40,
                child: const Icon(
                  Icons.location_on,
                  color: Colors.red,
                  size: 40,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }
}
