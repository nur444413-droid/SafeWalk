import '/auth/firebase_auth/auth_util.dart';
import '/backend/backend.dart';
import '/flutter_flow/flutter_flow_theme.dart';
import '/flutter_flow/flutter_flow_util.dart';
import '/flutter_flow/flutter_flow_widgets.dart';
import '/flutter_flow/custom_functions.dart' as functions;
import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import 'sendtomy_contacts_model.dart';
export 'sendtomy_contacts_model.dart';

class SendtomyContactsWidget extends StatefulWidget {
  const SendtomyContactsWidget({
    super.key,
    required this.lat,
    required this.lon,
  });

  final LatLng? lat;
  final LatLng? lon;

  @override
  State<SendtomyContactsWidget> createState() => _SendtomyContactsWidgetState();
}

class _SendtomyContactsWidgetState extends State<SendtomyContactsWidget> {
  late SendtomyContactsModel _model;

  @override
  void setState(VoidCallback callback) {
    super.setState(callback);
    _model.onUpdate();
  }

  @override
  void initState() {
    super.initState();
    _model = createModel(context, () => SendtomyContactsModel());
  }

  @override
  void dispose() {
    _model.maybeDispose();

    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return StreamBuilder<List<ContactsRecord>>(
      stream: queryContactsRecord(
        queryBuilder: (contactsRecord) => contactsRecord.where(
          'userRef',
          isEqualTo: currentUserReference,
        ),
      ),
      builder: (context, snapshot) {
        // Customize what your widget looks like when it's loading.
        if (!snapshot.hasData) {
          return Center(
            child: SizedBox(
              width: 50.0,
              height: 50.0,
              child: CircularProgressIndicator(
                valueColor: AlwaysStoppedAnimation<Color>(
                  FlutterFlowTheme.of(context).primary,
                ),
              ),
            ),
          );
        }
        List<ContactsRecord> listViewContactsRecordList = snapshot.data!;

        return ListView.separated(
          padding: EdgeInsets.fromLTRB(
            0,
            5.0,
            0,
            5.0,
          ),
          shrinkWrap: true,
          scrollDirection: Axis.vertical,
          itemCount: listViewContactsRecordList.length,
          separatorBuilder: (_, __) => SizedBox(height: 5.0),
          itemBuilder: (context, listViewIndex) {
            final listViewContactsRecord =
                listViewContactsRecordList[listViewIndex];
            return InkWell(
              splashColor: Colors.transparent,
              focusColor: Colors.transparent,
              hoverColor: Colors.transparent,
              highlightColor: Colors.transparent,
              onTap: () async {
                await launchURL(
                    'https://wa.me/${listViewContactsRecord.phoneNumber}?text=${functions.getLiveMapLink(currentUserDocument?.lastLocation)}');
              },
              child: Material(
                color: Colors.transparent,
                child: ListTile(
                  title: Text(
                    listViewContactsRecord.name,
                    style: FlutterFlowTheme.of(context).titleLarge.override(
                          font: GoogleFonts.interTight(
                            fontWeight: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .titleLarge
                                .fontStyle,
                          ),
                          color: Colors.black,
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .titleLarge
                              .fontWeight,
                          fontStyle:
                              FlutterFlowTheme.of(context).titleLarge.fontStyle,
                        ),
                  ),
                  subtitle: Text(
                    listViewContactsRecord.phoneNumber,
                    style: FlutterFlowTheme.of(context).labelMedium.override(
                          font: GoogleFonts.inter(
                            fontWeight: FlutterFlowTheme.of(context)
                                .labelMedium
                                .fontWeight,
                            fontStyle: FlutterFlowTheme.of(context)
                                .labelMedium
                                .fontStyle,
                          ),
                          letterSpacing: 0.0,
                          fontWeight: FlutterFlowTheme.of(context)
                              .labelMedium
                              .fontWeight,
                          fontStyle: FlutterFlowTheme.of(context)
                              .labelMedium
                              .fontStyle,
                        ),
                  ),
                  trailing: Icon(
                    Icons.send,
                    color: FlutterFlowTheme.of(context).secondaryText,
                    size: 24.0,
                  ),
                  tileColor: Color(0xFFFEFAFA),
                  dense: false,
                  contentPadding:
                      EdgeInsetsDirectional.fromSTEB(12.0, 0.0, 12.0, 0.0),
                  shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(8.0),
                  ),
                ),
              ),
            );
          },
        );
      },
    );
  }
}
